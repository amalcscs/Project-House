# YT-Django-Simple-Blog-App-Part6-Simple-Search
 
